//
// ZipCommon.h
//
// Library: Zip
// Package: Zip
// Module:  ZipCommon
//
// Definition of the ZipCommon class.
//
// Copyright (c) 2007, Applied Informatics Software Engineering GmbH.
// and Contributors.
//
// SPDX-License-Identifier:	BSL-1.0
//


#ifndef Zip_ZipCommon_INCLUDED
#define Zip_ZipCommon_INCLUDED


#include "Poco/Zip/Zip.h"


namespace Poco {
namespace Zip {


class Zip_API ZipCommon
	/// Common enums used in the Zip project
{
public:
	enum
	{
		HEADER_SIZE = 4
	};

	static const Poco::UInt16 ZIP64_EXTRA_ID	= 0x1;		  // Extra data id tag for Zip64 data (in extension for ZipLocalFileHeader and ZipFileInfo)
	static const Poco::UInt16 EXTRA_FIELD_HEADER_SIZE = 4;	  // Extra field header: id and data size
	static const Poco::UInt16 ZIP64_VALUE_SIZE	= 8;		  // One 64-bit value in a Zip64 extra field
	static const Poco::UInt16 ZIP64_MAGIC_SHORT = 0xFFFF;
	static const Poco::UInt32 ZIP64_MAGIC		= 0xFFFFFFFF;

	enum CompressionMethod
	{
		CM_STORE   = 0,
		CM_SHRUNK  = 1,
		CM_FACTOR1 = 2,
		CM_FACTOR2 = 3,
		CM_FACTOR3 = 4,
		CM_FACTOR4 = 5,
		CM_IMPLODE = 6,
		CM_TOKENIZE= 7,
		CM_DEFLATE = 8,
		CM_ENHANCEDDEFLATE = 9,
		CM_DATECOMPRIMPLODING = 10,
		CM_RESERVED11 = 11,
		CM_BZIP2 = 12,
		CM_RESERVED13 = 13,
		CM_LZMA = 14,
		CM_RESERVED15 = 15,
		CM_IBM_CMPSC = 16,
		CM_RESERVED17 = 17,
		CM_IBM_TERSE = 18,
		CM_IBM_LZ77 = 19,
		CM_ZSTD_DEPRECATED = 20,
		CM_ZSTD = 93,
		CM_MP3 = 94,
		CM_XZ = 95,
		CM_JPEG = 96,
		CM_WAVPACK = 97,
		CM_PPMD = 98,
		CM_AES = 99,
		CM_AUTO = 255 /// automatically select CM_DEFLATE or CM_STORE based on file type (extension)
	};

	enum CompressionLevel
	{
		CL_NORMAL    = 0,
		CL_MAXIMUM   = 1,
		CL_FAST      = 2,
		CL_SUPERFAST = 3
	};

	enum HostSystem
	{
		HS_FAT = 0,  // + PKZIPW 2.50 VFAT, NTFS
		HS_AMIGA = 1,
		HS_VMS = 2,
		HS_UNIX = 3,
		HS_VM_CMS = 4,
		HS_ATARI = 5,
		HS_HPFS = 6,
		HS_MACINTOSH = 7,
		HS_ZSYSTEM = 8,
		HS_CP_M = 9,
		HS_TOPS20 = 10, // used by pkzip2.5 to indicate ntfs
		HS_NTFS = 11,
		HS_SMS_QDOS = 12,
		HS_ACORN = 13,
		HS_VFAT = 14,
		HS_MVS = 15,
		HS_BEOS = 16,
		HS_TANDEM = 17,
		HS_UNUSED = 18
	};

	enum FileType
	{
		FT_BINARY= 0,
		FT_ASCII = 1
	};

	static bool isValidPath(const std::string& path);
		/// Checks whether the given path is valid (does
		/// not contain ".." path segments).
};


} } // namespace Poco::Zip


#endif // Zip_ZipCommon_INCLUDED
